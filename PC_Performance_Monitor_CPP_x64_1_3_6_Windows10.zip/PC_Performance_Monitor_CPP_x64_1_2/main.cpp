#define UNICODE
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <psapi.h>
#include <ntddstor.h>
#include <knownfolders.h>
#include <tlhelp32.h>
#include <winioctl.h>
#include <ntdddisk.h>
#include <evntrace.h>
#include <winevt.h>
#include <wbemidl.h>
#include <comdef.h>
#include <shellapi.h>
#include <shlobj.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iomanip>
#include <map>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#pragma comment(lib, "Comctl32.lib")
#pragma comment(lib, "Wbemuuid.lib")
#pragma comment(lib, "Wevtapi.lib")
#pragma comment(lib, "Advapi32.lib")
#pragma comment(lib, "Shell32.lib")

#ifndef SMART_GET_VERSION
#define SMART_GET_VERSION CTL_CODE(IOCTL_DISK_BASE, 0x0020, METHOD_BUFFERED, FILE_READ_ACCESS)
#endif
#ifndef SMART_RCV_DRIVE_DATA
#define SMART_RCV_DRIVE_DATA CTL_CODE(IOCTL_DISK_BASE, 0x0022, METHOD_BUFFERED, FILE_READ_ACCESS | FILE_WRITE_ACCESS)
#endif
#ifndef SMART_READ_DATA
#define SMART_READ_DATA 0xD0
#endif


namespace fs = std::filesystem;
static HINSTANCE g_instance{};
static HWND g_window{}, g_output{}, g_status{};
static std::mutex g_uiMutex;
static bool g_closing = false; // accessed on UI thread only
static std::atomic<unsigned> g_activeTasks{0};
static std::wstring g_smartctl = L"smartctl.exe";
static constexpr UINT WM_APP_RESULT = WM_APP + 41;

static std::wstring Widen(const std::string& s) {
    if (s.empty()) return {};
    int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
    if (!n) return L"(conversion error)";
    std::wstring out(n, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), out.data(), n);
    return out;
}
static std::string Utf8(const std::wstring& s) {
    if (s.empty()) return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0, nullptr, nullptr);
    std::string out(n, '\0');
    WideCharToMultiByte(CP_UTF8, 0, s.data(), (int)s.size(), out.data(), n, nullptr, nullptr);
    return out;
}
static void Append(const std::wstring& s) {
    if (!g_output) return;
    int len = GetWindowTextLengthW(g_output);
    SendMessageW(g_output, EM_SETSEL, len, len);
    SendMessageW(g_output, EM_REPLACESEL, FALSE, (LPARAM)s.c_str());
}
static void SetStatus(const std::wstring& s) {
    if (g_status) SetWindowTextW(g_status, s.c_str());
}
static std::wstring Timestamp() {
    SYSTEMTIME t{}; GetLocalTime(&t);
    wchar_t b[64]; swprintf_s(b, L"%04u-%02u-%02u %02u:%02u:%02u",
        t.wYear,t.wMonth,t.wDay,t.wHour,t.wMinute,t.wSecond);
    return b;
}
static std::wstring RunCapture(const std::wstring& command, DWORD timeoutMs = 120000) {
    SECURITY_ATTRIBUTES sa{ sizeof(sa), nullptr, TRUE };
    HANDLE readPipe{}, writePipe{};
    if (!CreatePipe(&readPipe, &writePipe, &sa, 0)) return L"CreatePipe failed.";
    SetHandleInformation(readPipe, HANDLE_FLAG_INHERIT, 0);
    STARTUPINFOW si{}; si.cb = sizeof(si); si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE; si.hStdOutput = writePipe; si.hStdError = writePipe; si.hStdInput = GetStdHandle(STD_INPUT_HANDLE);
    PROCESS_INFORMATION pi{};
    std::wstring cmd = L"cmd.exe /d /s /c \"" + command + L"\"";
    BOOL ok = CreateProcessW(nullptr, cmd.data(), nullptr, nullptr, TRUE, CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi);
    CloseHandle(writePipe);
    if (!ok) { CloseHandle(readPipe); return L"Не удалось запустить команду. Проверьте наличие smartctl.exe."; }
    std::string bytes; bytes.reserve(8192);
    DWORD start = GetTickCount(), available = 0, got = 0;
    char buf[4096];
    bool finished = false;
    while (GetTickCount() - start < timeoutMs) {
        while (PeekNamedPipe(readPipe, nullptr, 0, nullptr, &available, nullptr) && available) {
            if (!ReadFile(readPipe, buf, (DWORD)std::min<DWORD>(available, sizeof(buf)), &got, nullptr) || !got) break;
            bytes.append(buf, got);
        }
        DWORD wait = WaitForSingleObject(pi.hProcess, 50);
        if (wait == WAIT_OBJECT_0) { finished = true; break; }
    }
    if (!finished) TerminateProcess(pi.hProcess, 124);
    while (PeekNamedPipe(readPipe, nullptr, 0, nullptr, &available, nullptr) && available) {
        if (!ReadFile(readPipe, buf, (DWORD)std::min<DWORD>(available, sizeof(buf)), &got, nullptr) || !got) break;
        bytes.append(buf, got);
    }
    DWORD exitCode = 0; GetExitCodeProcess(pi.hProcess, &exitCode);
    CloseHandle(pi.hThread); CloseHandle(pi.hProcess); CloseHandle(readPipe);
    // smartctl on Windows normally emits the active OEM code page; try UTF-8, then ACP.
    std::wstring result;
    if (!bytes.empty()) {
        int n = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, bytes.data(), (int)bytes.size(), nullptr, 0);
        if (n) { result.resize(n); MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, bytes.data(), (int)bytes.size(), result.data(), n); }
        else {
            n = MultiByteToWideChar(CP_ACP, 0, bytes.data(), (int)bytes.size(), nullptr, 0);
            result.resize(n); if (n) MultiByteToWideChar(CP_ACP, 0, bytes.data(), (int)bytes.size(), result.data(), n);
        }
    }
    if (!finished) result += L"\r\n[ВНИМАНИЕ: команда остановлена по тайм-ауту]\r\n";
    result += L"\r\n[Код завершения smartctl/команды: " + std::to_wstring(exitCode) + L"]\r\n";
    return result;
}
static std::wstring AppDataDir() {
    PWSTR p = nullptr; std::wstring out = L".";
    if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_LocalAppData, 0, nullptr, &p))) {
        out = p; CoTaskMemFree(p); out += L"\\PCPerformanceMonitor";
        CreateDirectoryW(out.c_str(), nullptr);
    }
    return out;
}
static std::wstring SnapshotPath() { return AppDataDir() + L"\\disk_write_history.csv"; }

struct NvmeHealth {
    bool ok = false;
    double temperatureC = 0;
    unsigned spare = 0, used = 0;
    // NVMe counters are 128-bit little-endian values. Keep their full decimal
    // representation; silently truncating to 64 bits corrupts long-running-drive statistics.
    std::wstring dataUnitsWritten, powerCycles, powerOnHours, unsafeShutdowns, mediaErrors;
    std::wstring error;
};

// Native NVMe Health Information Log Page (02h), via Windows storage protocol query.
static NvmeHealth ReadNvmeHealth(unsigned diskNo) {
    NvmeHealth r;
    std::wstring path = L"\\\\.\\PhysicalDrive" + std::to_wstring(diskNo);
    HANDLE h = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
        nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE) { r.error = L"Нет доступа к устройству"; return r; }

    struct Query {
        STORAGE_PROPERTY_QUERY query;
        STORAGE_PROTOCOL_SPECIFIC_DATA protocol;
    } q{};
    q.query.PropertyId = StorageDeviceProtocolSpecificProperty;
    q.query.QueryType = PropertyStandardQuery;
    q.protocol.ProtocolType = ProtocolTypeNvme;
    q.protocol.DataType = NVMeDataTypeLogPage;
    q.protocol.ProtocolDataRequestValue = 0x02; // SMART / Health Information
    q.protocol.ProtocolDataRequestSubValue = 0;
    q.protocol.ProtocolDataOffset = sizeof(STORAGE_PROTOCOL_SPECIFIC_DATA);
    q.protocol.ProtocolDataLength = 512;

    std::array<BYTE, sizeof(STORAGE_PROTOCOL_DATA_DESCRIPTOR) + 512> buffer{};
    DWORD returned = 0;
    BOOL ok = DeviceIoControl(h, IOCTL_STORAGE_QUERY_PROPERTY, &q, sizeof(q),
        buffer.data(), (DWORD)buffer.size(), &returned, nullptr);
    CloseHandle(h);
    if (!ok || returned < sizeof(STORAGE_PROTOCOL_DATA_DESCRIPTOR)) {
        r.error = L"Windows не предоставила NVMe Health Log (драйвер/контроллер может не поддерживать запрос)";
        return r;
    }
    auto* desc = reinterpret_cast<STORAGE_PROTOCOL_DATA_DESCRIPTOR*>(buffer.data());
    auto* p = reinterpret_cast<STORAGE_PROTOCOL_SPECIFIC_DATA*>(&desc->ProtocolSpecificData);
    const size_t protocolBase = offsetof(STORAGE_PROTOCOL_DATA_DESCRIPTOR, ProtocolSpecificData);
    if (p->ProtocolDataOffset < sizeof(STORAGE_PROTOCOL_SPECIFIC_DATA) ||
        protocolBase + p->ProtocolDataOffset + p->ProtocolDataLength > returned ||
        p->ProtocolDataLength < 176) {
        r.error = L"Некорректная длина NVMe Health Log"; return r;
    }
    const BYTE* d = reinterpret_cast<const BYTE*>(p) + p->ProtocolDataOffset;
    auto le128Decimal = [](const BYTE* x) -> std::wstring {
        // Convert an unsigned 128-bit little-endian integer without compiler-specific
        // __int128 support (MSVC does not provide that type).
        std::wstring decimal = L"0";
        for (int i = 15; i >= 0; --i) {
            unsigned carry = x[i];
            for (auto it = decimal.rbegin(); it != decimal.rend(); ++it) {
                const unsigned value = unsigned(*it - L'0') * 256u + carry;
                *it = wchar_t(L'0' + (value % 10u));
                carry = value / 10u;
            }
            while (carry) {
                decimal.insert(decimal.begin(), wchar_t(L'0' + (carry % 10u)));
                carry /= 10u;
            }
        }
        const auto nonzero = decimal.find_first_not_of(L'0');
        return nonzero == std::wstring::npos ? L"0" : decimal.substr(nonzero);
    };
    unsigned short kelvin = (unsigned short)(d[1] | (d[2] << 8));
    r.temperatureC = kelvin ? (double)kelvin - 273.15 : 0;
    r.spare = d[3]; r.used = d[5];
    r.dataUnitsWritten = le128Decimal(d + 48);
    r.powerCycles = le128Decimal(d + 112);
    r.powerOnHours = le128Decimal(d + 128);
    r.unsafeShutdowns = le128Decimal(d + 144);
    r.mediaErrors = le128Decimal(d + 160);
    r.ok = true;
    return r;
}

static std::wstring NativeNvmeReport() {
    std::wstringstream ss; ss << L"=== Нативный NVMe Health Log ===\r\n";
    bool any = false;
    for (unsigned i=0; i<32; ++i) {
        std::wstring p = L"\\\\.\\PhysicalDrive" + std::to_wstring(i);
        HANDLE h = CreateFileW(p.c_str(), 0, FILE_SHARE_READ|FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
        if (h == INVALID_HANDLE_VALUE) continue;
        CloseHandle(h);
        auto n = ReadNvmeHealth(i);
        ss << L"\r\nPhysicalDrive" << i << L": ";
        if (!n.ok) { ss << n.error << L"\r\n"; continue; }
        any = true;
        ss << L"\r\nТемпература: " << std::fixed << std::setprecision(1) << n.temperatureC << L" °C"
           << L"\r\nЗапас ресурса: " << n.spare << L"%"
           << L"\r\nИзнос (Percentage Used): " << n.used << L"%"
           << L"\r\nData Units Written: " << n.dataUnitsWritten
           << L"\r\nPower Cycles: " << n.powerCycles
           << L"\r\nPower-On Hours: " << n.powerOnHours
           << L"\r\nUnsafe Shutdowns: " << n.unsafeShutdowns
           << L"\r\nMedia/Data Integrity Errors: " << n.mediaErrors << L"\r\n";
    }
    if (!any) ss << L"Нет доступных NVMe Health Log. Для полного отчёта используйте smartctl -x.\r\n";
    return ss.str();
}


static std::wstring AtaSmartReport(unsigned diskNo) {
    std::wstring path = L"\\\\.\\PhysicalDrive" + std::to_wstring(diskNo);
    HANDLE h = CreateFileW(path.c_str(), GENERIC_READ | GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
    if (h == INVALID_HANDLE_VALUE) return L"";
    GETVERSIONINPARAMS ver{}; DWORD returned = 0;
    if (!DeviceIoControl(h, SMART_GET_VERSION, nullptr, 0, &ver, sizeof(ver), &returned, nullptr) ||
        !ver.fCapabilities) { CloseHandle(h); return L""; }
    struct InBuffer { SENDCMDINPARAMS p; BYTE extra[1]; } in{};
    in.p.cBufferSize = 512; in.p.bDriveNumber = (BYTE)diskNo;
    in.p.irDriveRegs.bFeaturesReg = SMART_READ_DATA;
    in.p.irDriveRegs.bSectorCountReg = 1; in.p.irDriveRegs.bSectorNumberReg = 1;
    in.p.irDriveRegs.bCylLowReg = 0x4F; in.p.irDriveRegs.bCylHighReg = 0xC2;
    in.p.irDriveRegs.bDriveHeadReg = (BYTE)(0xA0 | ((diskNo & 1) << 4));
    in.p.irDriveRegs.bCommandReg = SMART_CMD;
    std::array<BYTE, sizeof(SENDCMDOUTPARAMS) + 512> out{};
    BOOL ok = DeviceIoControl(h, SMART_RCV_DRIVE_DATA, &in, sizeof(SENDCMDINPARAMS) - 1,
        out.data(), (DWORD)out.size(), &returned, nullptr);
    CloseHandle(h);
    if (!ok || returned < sizeof(SENDCMDOUTPARAMS) + 511) return L"";
#pragma pack(push, 1)
    struct AtaAttr { BYTE id; BYTE flags[2]; BYTE current; BYTE worst; BYTE raw[6]; BYTE reserved; };
    struct AtaData { BYTE revision[2]; AtaAttr attributes[30]; BYTE reserved[150]; };
#pragma pack(pop)
    const auto* d = reinterpret_cast<const AtaData*>(out.data() + sizeof(SENDCMDOUTPARAMS) - 1);
    std::wstringstream ss;
    ss << L"\r\n=== ATA SMART PhysicalDrive" << diskNo << L" ===\r\nID\tCurrent\tWorst\tRaw(hex)\r\n";
    for (const auto& a : d->attributes) if (a.id) {
        wchar_t raw[16]{};
        swprintf_s(raw, L"%02X%02X%02X%02X%02X%02X", a.raw[5], a.raw[4], a.raw[3], a.raw[2], a.raw[1], a.raw[0]);
        ss << (unsigned)a.id << L"\t" << (unsigned)a.current << L"\t" << (unsigned)a.worst << L"\t" << raw << L"\r\n";
    }
    ss << L"Raw-значения зависят от производителя; универсальная трактовка не гарантируется.\r\n";
    return ss.str();
}
static std::wstring NativeAtaReport() {
    std::wstring out = L"=== Нативный ATA SMART ===\r\n"; bool found = false;
    for (unsigned i = 0; i < 32; ++i) {
        auto r = AtaSmartReport(i);
        if (!r.empty()) { out += r; found = true; }
    }
    if (!found) out += L"ATA SMART IOCTL недоступен через storage-драйвер; используйте smartctl.\r\n";
    return out;
}

struct SmartctlDevice {
    std::wstring path;
    std::wstring options;
};
static std::vector<SmartctlDevice> SmartctlDevices() {
    std::vector<SmartctlDevice> devices;
    const std::wstring scan = RunCapture(L"\"" + g_smartctl + L"\" --scan-open", 30000);
    std::wistringstream lines(scan);
    std::wstring line;
    auto safeSmartctlToken = [](const std::wstring& token) {
        if (token.empty() || token.size() > 128) return false;
        return std::all_of(token.begin(), token.end(), [](wchar_t c) {
            return (c >= L'a' && c <= L'z') || (c >= L'A' && c <= L'Z') ||
                   (c >= L'0' && c <= L'9') || c == L'_' || c == L'-' ||
                   c == L'.' || c == L',' || c == L':' || c == L'/';
        });
    };
    while (std::getline(lines, line)) {
        const auto first = line.find_first_not_of(L" \t\r");
        if (first == std::wstring::npos || line[first] != L'/') continue;
        const auto comment = line.find(L'#', first);
        const std::wstring data = line.substr(first, comment == std::wstring::npos ? comment : comment-first);
        std::wistringstream tokens(data);
        SmartctlDevice item;
        if (!(tokens >> item.path) || item.path.rfind(L"/dev/", 0) != 0 ||
            !safeSmartctlToken(item.path)) continue;
        std::wstring token;
        bool validOptions = true;
        while (tokens >> token) {
            if (!safeSmartctlToken(token)) { validOptions = false; break; }
            item.options += L" " + token;
        }
        if (!validOptions) continue;
        auto it = std::find_if(devices.begin(), devices.end(), [&](const SmartctlDevice& d) { return d.path == item.path; });
        if (it == devices.end()) devices.push_back(std::move(item));
        else if (it->options.empty()) it->options = item.options;
    }
    return devices;
}
static std::wstring SmartctlCommand(const std::wstring& args, const SmartctlDevice& device) {
    return L"\"" + g_smartctl + L"\"" + device.options + L" " + args + L" " + device.path;
}
static std::wstring SmartReport() {
    std::wstring report = NativeNvmeReport() + NativeAtaReport();
    report += L"\r\n=== smartctl --scan-open ===\r\n";
    report += RunCapture(L"\"" + g_smartctl + L"\" --scan-open", 30000);
    auto devices = SmartctlDevices();
    if (devices.empty()) {
        report += L"\r\nУстройства smartctl не обнаружены. Проверьте smartctl.exe и права администратора.\r\n";
        return report;
    }
    report += L"\r\n=== smartctl -x: полный отчёт по обнаруженным устройствам ===\r\n";
    for (const auto& device : devices) {
        report += L"\r\n--- " + device.path + device.options + L" ---\r\n";
        report += RunCapture(SmartctlCommand(L"-x", device), 120000);
    }
    return report;
}
static std::wstring SmartTests() {
    std::wstring report = L"=== Обнаружение устройств ===\r\n";
    report += RunCapture(L"\"" + g_smartctl + L"\" --scan-open", 30000);
    auto devices = SmartctlDevices();
    if (devices.empty()) return report + L"\r\nНет доступных устройств smartctl.\r\n";
    for (const auto& device : devices) {
        report += L"\r\n--- Self-test capabilities: " + device.path + device.options + L" ---\r\n";
        report += RunCapture(SmartctlCommand(L"-c", device), 30000);
    }
    return report;
}
static std::wstring RunSmartTest(const wchar_t* option) {
    auto devices = SmartctlDevices();
    if (devices.empty()) return L"Устройства smartctl не обнаружены.\r\n";
    std::wstring report;
    for (const auto& device : devices) {
        report += L"\r\n--- " + device.path + device.options + L" ---\r\n";
        report += RunCapture(SmartctlCommand(option, device), 120000);
    }
    return report;
}

static std::wstring DiskList() {
    std::wstringstream ss;
    for (unsigned i=0; i<32; ++i) {
        std::wstring p = L"\\\\.\\PhysicalDrive" + std::to_wstring(i);
        HANDLE h = CreateFileW(p.c_str(), 0, FILE_SHARE_READ|FILE_SHARE_WRITE, nullptr, OPEN_EXISTING, 0, nullptr);
        if (h == INVALID_HANDLE_VALUE) continue;
        STORAGE_PROPERTY_QUERY q{}; q.PropertyId = StorageDeviceProperty; q.QueryType = PropertyStandardQuery;
        std::array<BYTE, 2048> b{}; DWORD ret = 0;
        if (DeviceIoControl(h, IOCTL_STORAGE_QUERY_PROPERTY, &q, sizeof(q), b.data(), (DWORD)b.size(), &ret, nullptr)) {
            auto* d = reinterpret_cast<STORAGE_DEVICE_DESCRIPTOR*>(b.data());
            ss << L"PhysicalDrive" << i;
            if (d->VendorIdOffset && d->VendorIdOffset < ret) ss << L" | " << Widen((char*)b.data()+d->VendorIdOffset);
            if (d->ProductIdOffset && d->ProductIdOffset < ret) ss << L" " << Widen((char*)b.data()+d->ProductIdOffset);
            ss << L"\r\n";
        } else ss << L"PhysicalDrive" << i << L"\r\n";
        CloseHandle(h);
    }
    return ss.str();
}

static void SaveNvmeSnapshots() {
    const std::wstring path = SnapshotPath();
    std::error_code sizeError;
    const auto existingSize = fs::exists(path, sizeError) && !sizeError ? fs::file_size(path, sizeError) : 0;
    std::wofstream f(path, std::ios::app);
    if (!f) return;
    if (existingSize == 0) f << L"timestamp,disk,data_units_written,power_on_hours,percentage_used\r\n";
    for (unsigned i=0; i<32; ++i) {
        auto n = ReadNvmeHealth(i);
        if (!n.ok) continue;
        f << Timestamp() << L"," << i << L"," << n.dataUnitsWritten << L"," << n.powerOnHours << L"," << n.used << L"\r\n";
    }
}
static std::wstring TbwReport() {
    SaveNvmeSnapshots();
    const std::wstring history = SnapshotPath();
    const std::wstring profile = AppDataDir() + L"\\ssd_tbw_profiles.csv";
    if (!fs::exists(profile)) {
        std::wofstream pf(profile);
        if (pf) pf << L"disk_number,rated_tbw_TB\r\n0,600\r\n";
    }
    struct Snap { long long epoch; unsigned long long units; };
    std::map<unsigned, std::vector<Snap>> snapshots;
    std::wifstream in(history);
    std::wstring line;
    std::getline(in, line);
    while (std::getline(in, line)) {
        std::wistringstream row(line);
        std::wstring stamp, diskText, unitsText, hoursText, usedText;
        if (!std::getline(row, stamp, L',') || !std::getline(row, diskText, L',') ||
            !std::getline(row, unitsText, L',') || !std::getline(row, hoursText, L',') ||
            !std::getline(row, usedText, L',')) continue;
        int y=0, mo=0, d=0, hh=0, mm=0, sec=0;
        unsigned disk=0; unsigned long long units=0;
        if (swscanf_s(stamp.c_str(), L"%d-%d-%d %d:%d:%d", &y,&mo,&d,&hh,&mm,&sec) != 6) continue;
        try { disk=(unsigned)std::stoul(diskText); units=std::stoull(unitsText); } catch (...) { continue; }
        std::tm tm{}; tm.tm_year=y-1900; tm.tm_mon=mo-1; tm.tm_mday=d;
        tm.tm_hour=hh; tm.tm_min=mm; tm.tm_sec=sec;
        snapshots[disk].push_back({(long long)_mkgmtime(&tm), units});
    }
    std::map<unsigned, double> rated;
    std::wifstream pf(profile);
    std::getline(pf, line);
    while (std::getline(pf, line)) {
        std::wistringstream row(line); std::wstring ds, tbw;
        if (!std::getline(row, ds, L',') || !std::getline(row, tbw, L',')) continue;
        try { rated[(unsigned)std::stoul(ds)] = std::stod(tbw); } catch (...) {}
    }
    std::wstringstream ss;
    ss << L"=== История записи и оценка TBW ===\r\nИстория: " << history
       << L"\r\nПрофиль ресурса: " << profile
       << L"\r\nNVMe Data Units Written: одна единица = 512 000 байт.\r\n";
    for (auto& item : snapshots) {
        auto& v = item.second;
        if (v.empty()) continue;
        std::sort(v.begin(), v.end(), [](const Snap& a, const Snap& b){ return a.epoch < b.epoch; });
        const auto& first = v.front(); const auto& last = v.back();
        const double totalTB = last.units * 512000.0 / 1e12;
        ss << L"\r\nPhysicalDrive" << item.first << L": накопленная запись ≈ "
           << std::fixed << std::setprecision(3) << totalTB << L" TB.";
        if (v.size() < 2 || last.epoch <= first.epoch || last.units < first.units) {
            ss << L" Для расчёта темпа нужны два корректных снимка.\r\n"; continue;
        }
        const double days = (last.epoch - first.epoch) / 86400.0;
        const double writtenTB = (last.units - first.units) * 512000.0 / 1e12;
        const double perDay = writtenTB / days;
        ss << L"\r\nПериод наблюдения: " << days << L" дней; запись за период: "
           << writtenTB << L" TB; средний темп: " << perDay << L" TB/день.";
        auto it = rated.find(item.first);
        if (it != rated.end() && it->second > 0) {
            const double remaining = std::max(0.0, it->second - totalTB);
            ss << L"\r\nПаспортный ресурс: " << it->second << L" TBW; условный остаток: "
               << remaining << L" TB.";
            if (perDay > 0) ss << L"\r\nЛинейная оценка до TBW: " << remaining / perDay << L" дней.";
        } else {
            ss << L"\r\nПрогноз не рассчитан: укажите паспортный TBW в профиле.";
        }
        ss << L"\r\n";
    }
    ss << L"\r\nОткройте ssd_tbw_profiles.csv и укажите фактический паспортный TBW для каждого диска. "
       << L"Прогноз линейный, зависит от периода наблюдения и не является гарантией срока службы.\r\n";
    return ss.str();
}

static std::wstring WmiQuery(const wchar_t* query, const wchar_t* property) {
    HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    bool uninit = SUCCEEDED(hr);
    IWbemLocator* loc = nullptr; IWbemServices* svc = nullptr;
    std::wstringstream out;
    hr = CoCreateInstance(CLSID_WbemLocator, 0, CLSCTX_INPROC_SERVER, IID_IWbemLocator, (void**)&loc);
    if (FAILED(hr)) { if (uninit) CoUninitialize(); return L"WMI недоступен.\r\n"; }
    BSTR ns = SysAllocString(L"ROOT\\CIMV2");
    hr = loc->ConnectServer(ns, nullptr, nullptr, nullptr, 0, nullptr, nullptr, &svc);
    SysFreeString(ns);
    if (SUCCEEDED(hr)) {
        CoSetProxyBlanket(svc, RPC_C_AUTHN_WINNT, RPC_C_AUTHZ_NONE, nullptr, RPC_C_AUTHN_LEVEL_CALL,
            RPC_C_IMP_LEVEL_IMPERSONATE, nullptr, EOAC_NONE);
        IEnumWbemClassObject* en = nullptr;
        BSTR q = SysAllocString(query);
        BSTR language = SysAllocString(L"WQL");
        hr = svc->ExecQuery(language, q, WBEM_FLAG_FORWARD_ONLY|WBEM_FLAG_RETURN_IMMEDIATELY, nullptr, &en);
        SysFreeString(language);
        SysFreeString(q);
        if (SUCCEEDED(hr) && en) {
            IWbemClassObject* obj = nullptr; ULONG count = 0;
            while (en->Next(WBEM_INFINITE, 1, &obj, &count) == S_OK && count) {
                VARIANT v; VariantInit(&v);
                if (SUCCEEDED(obj->Get(property, 0, &v, nullptr, nullptr))) {
                    _bstr_t b(v); out << (const wchar_t*)b << L"\r\n";
                }
                VariantClear(&v); obj->Release();
            }
            en->Release();
        }
        svc->Release();
    }
    loc->Release(); if (uninit) CoUninitialize();
    return out.str();
}
static std::wstring HardwareReport() {
    std::wstringstream ss;
    ss << L"=== CPU ===\r\n" << WmiQuery(L"SELECT Name,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed FROM Win32_Processor", L"Name");
    ss << L"\r\n=== Модули памяти ===\r\n";
    ss << L"Производитель: " << WmiQuery(L"SELECT Manufacturer FROM Win32_PhysicalMemory", L"Manufacturer");
    ss << L"Модель: " << WmiQuery(L"SELECT PartNumber FROM Win32_PhysicalMemory", L"PartNumber");
    ss << L"Объём (байт): " << WmiQuery(L"SELECT Capacity FROM Win32_PhysicalMemory", L"Capacity");
    ss << L"Скорость (MT/s): " << WmiQuery(L"SELECT Speed FROM Win32_PhysicalMemory", L"Speed");
    ss << L"Настроенная скорость (MT/s): " << WmiQuery(L"SELECT ConfiguredClockSpeed FROM Win32_PhysicalMemory", L"ConfiguredClockSpeed");
    ss << L"\r\n=== Температурные зоны ACPI (если доступны) ===\r\n";
    ss << WmiQuery(L"SELECT CurrentTemperature FROM MSAcpi_ThermalZoneTemperature", L"CurrentTemperature");
    ss << L"Примечание: ACPI часто не предоставляет температуру CPU/GPU на современных ПК.\r\n";
    return ss.str();
}

static std::wstring EventReport(const wchar_t* channel, const wchar_t* label, DWORD maxEvents = 250) {
    std::wstringstream ss; ss << L"=== " << label << L" ===\r\n";
    EVT_HANDLE query = EvtQuery(nullptr, channel, L"*", EvtQueryChannelPath | EvtQueryReverseDirection);
    if (!query) { ss << L"Журнал недоступен (код " << GetLastError() << L").\r\n"; return ss.str(); }
    std::array<EVT_HANDLE, 32> events{}; DWORD returned = 0, total = 0;
    while (total < maxEvents && EvtNext(query, (DWORD)events.size(), events.data(), 1000, 0, &returned)) {
        for (DWORD i=0; i<returned && total<maxEvents; ++i, ++total) {
            DWORD used = 0, props = 0;
            EvtRender(nullptr, events[i], EvtRenderEventXml, 0, nullptr, &used, &props);
            if (GetLastError() == ERROR_INSUFFICIENT_BUFFER && used) {
                std::vector<wchar_t> xml(used/sizeof(wchar_t)+1);
                if (EvtRender(nullptr, events[i], EvtRenderEventXml, used, xml.data(), &used, &props))
                    ss << xml.data() << L"\r\n";
            }
            EvtClose(events[i]);
        }
    }
    EvtClose(query);
    ss << L"\r\nПоказано событий: " << total << L"\r\n";
    return ss.str();
}
static std::wstring DiagnosticsReport() {
    return EventReport(L"System", L"WHEA / аппаратные ошибки") +
        EventReport(L"Microsoft-Windows-MemoryDiagnostics-Results/Operational", L"Windows Memory Diagnostics");
}

static std::wstring ProcessReport() {
    std::wstringstream ss; ss << L"PID\tПамять (КБ)\tПроцесс\r\n";
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return L"Не удалось получить список процессов.\r\n";
    PROCESSENTRY32W pe{}; pe.dwSize = sizeof(pe);
    if (Process32FirstW(snap, &pe)) do {
        HANDLE p = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pe.th32ProcessID);
        SIZE_T mem = 0; if (p) { PROCESS_MEMORY_COUNTERS_EX pm{}; pm.cb=sizeof(pm);
            if (GetProcessMemoryInfo(p, (PROCESS_MEMORY_COUNTERS*)&pm, sizeof(pm))) mem=pm.WorkingSetSize/1024; CloseHandle(p); }
        ss << pe.th32ProcessID << L"\t" << mem << L"\t" << pe.szExeFile << L"\r\n";
    } while (Process32NextW(snap, &pe));
    CloseHandle(snap); return ss.str();
}
static std::wstring StartupReport() {
    std::wstringstream ss;
    const wchar_t* paths[] = {
        L"Software\\Microsoft\\Windows\\CurrentVersion\\Run",
        L"Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce"
    };
    for (auto hive : { HKEY_CURRENT_USER, HKEY_LOCAL_MACHINE }) for (auto path : paths) {
        ss << L"\r\n[" << (hive==HKEY_CURRENT_USER?L"HKCU":L"HKLM") << L"\\" << path << L"]\r\n";
        HKEY key{}; if (RegOpenKeyExW(hive,path,0,KEY_READ| (hive==HKEY_LOCAL_MACHINE?KEY_WOW64_64KEY:0),&key)!=ERROR_SUCCESS) continue;
        for (DWORD i=0;;++i) {
            wchar_t name[512], value[2048]; DWORD ns=512, vs=sizeof(value), type=0;
            LONG rc=RegEnumValueW(key,i,name,&ns,nullptr,&type,(BYTE*)value,&vs);
            if (rc==ERROR_NO_MORE_ITEMS) break; if (rc!=ERROR_SUCCESS) continue;
            if (type==REG_SZ || type==REG_EXPAND_SZ) ss << name << L" = " << value << L"\r\n";
        }
        RegCloseKey(key);
    }
    ss << L"\r\nРежим просмотра: автоматическое изменение записей не выполняется.\r\n";
    return ss.str();
}

static std::wstring TempScan() {
    std::vector<std::wstring> dirs;
    wchar_t t[MAX_PATH]{}, w[MAX_PATH]{};
    GetTempPathW(MAX_PATH,t); dirs.push_back(t);
    if (GetWindowsDirectoryW(w,MAX_PATH)) dirs.push_back(std::wstring(w)+L"\\Temp");
    unsigned long long bytes=0, files=0, errors=0;
    for (const auto& d:dirs) {
        std::error_code ec;
        for (fs::recursive_directory_iterator it(d, fs::directory_options::skip_permission_denied, ec), end; it!=end; it.increment(ec)) {
            if (ec) { ++errors; ec.clear(); continue; }
            if (!it->is_regular_file(ec)) continue;
            auto sz=it->file_size(ec); if (!ec) { bytes+=sz; ++files; } else { ++errors; ec.clear(); }
        }
    }
    std::wstringstream ss; ss << L"=== Временные файлы (только анализ) ===\r\nКаталогов: " << dirs.size()
        << L"\r\nФайлов: " << files << L"\r\nОбъём: " << (bytes/1048576.0) << L" MiB\r\nОшибок доступа: " << errors
        << L"\r\nУдаление не выполняется. Это защищает открытые и нужные приложениям файлы.\r\n";
    return ss.str();
}

static std::wstring RamIndex() {
    MEMORYSTATUSEX m{}; m.dwLength=sizeof(m); GlobalMemoryStatusEx(&m);
    unsigned score=99; std::wstring reason=L"Нагрузка памяти умеренная.";
    if (m.dwMemoryLoad>=95) { score=25; reason=L"Критически высокая занятость RAM."; }
    else if (m.dwMemoryLoad>=85) { score=50; reason=L"Высокая занятость RAM."; }
    else if (m.dwMemoryLoad>=70) { score=75; reason=L"Повышенная занятость RAM."; }
    std::wstringstream ss; ss << L"=== Индекс оперативной памяти (эвристика) ===\r\nОценка: " << score << L"%\r\n"
        << L"Занято: " << m.dwMemoryLoad << L"%\r\n" << reason
        << L"\r\nЭто оценка текущей нагрузки, а не физического износа модулей.\r\n"
        << L"Стандартного счётчика включений/выключений RAM-модулей обычно нет.\r\n";
    return ss.str();
}

static std::wstring Benchmark() {
    wchar_t temp[MAX_PATH]{}; GetTempPathW(MAX_PATH,temp);
    std::wstring path=std::wstring(temp)+L"PCPM_benchmark.tmp";
    constexpr size_t total=128ull*1024*1024;
    std::vector<BYTE> block(4*1024*1024,0x5A);
    HANDLE h=CreateFileW(path.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_TEMPORARY|FILE_FLAG_SEQUENTIAL_SCAN,nullptr);
    if(h==INVALID_HANDLE_VALUE) return L"Не удалось создать временный файл для теста.";
    auto a=std::chrono::steady_clock::now(); size_t written=0; DWORD n=0; bool ok=true;
    while(written<total) { if(!WriteFile(h,block.data(),(DWORD)block.size(),&n,nullptr)||!n){ok=false;break;} written+=n; }
    FlushFileBuffers(h); CloseHandle(h); auto b=std::chrono::steady_clock::now();
    std::error_code ec; fs::remove(path,ec);
    double sec=std::chrono::duration<double>(b-a).count();
    std::wstringstream ss; ss << L"=== Последовательная запись (временный файл) ===\r\nОбъём: " << written/1048576
        << L" MiB\r\nВремя: " << sec << L" с\r\nСкорость: " << (sec>0?written/1048576.0/sec:0) << L" MiB/s\r\n"
        << L"Результат: " << (ok?L"завершён":L"ошибка записи") << L"\r\n"
        << L"Тест кратковременный и зависит от кэша ОС/накопителя; не является полным бенчмарком SSD.\r\n";
    return ss.str();
}

static void ShowResult(std::wstring* p) {
    if (!p) return;
    if (g_window && !g_closing) {
        SetWindowTextW(g_output, p->c_str());
        SetStatus(L"Готово");
    }
    delete p;
}
static void StartTask(const std::wstring& name, std::function<std::wstring()> fn) {
    if (g_closing || !g_window) return;
    SetStatus(L"Выполняется: " + name);
    EnableWindow(g_window, FALSE);
    ++g_activeTasks;
    HWND target = g_window;
    std::thread([target, name, fn=std::move(fn)]() {
        std::wstring body;
        try { body = fn(); }
        catch (const std::exception& e) { body = L"Ошибка фоновой задачи (std::exception)."; }
        catch (...) { body = L"Неизвестная ошибка фоновой задачи."; }
        auto* result = new std::wstring(L"[" + name + L"]\r\n" + Timestamp() + L"\r\n\r\n" + body);
        // WM_CLOSE is deferred until all workers report completion, so target remains valid.
        if (!PostMessageW(target, WM_APP_RESULT, 0, (LPARAM)result)) {
            delete result;
            --g_activeTasks;
        }
    }).detach();
}
static void AddButton(HWND parent, const wchar_t* label, int id, int x, int y, int w=150) {
    CreateWindowW(L"BUTTON",label,WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,x,y,w,30,parent,(HMENU)(INT_PTR)id,g_instance,nullptr);
}
enum { ID_HARDWARE=100, ID_SMART, ID_TEST_SHORT, ID_TEST_LONG, ID_TEST_CANCEL, ID_DISKS, ID_DIAG, ID_PROCESSES,
       ID_STARTUP, ID_RAM, ID_TBW, ID_TEMP, ID_BENCH, ID_SAVE, ID_CANCEL_TEST };
static void SaveReport() {
    wchar_t file[MAX_PATH]=L"PC_Performance_Report.txt";
    OPENFILENAMEW ofn{}; ofn.lStructSize=sizeof(ofn); ofn.hwndOwner=g_window; ofn.lpstrFilter=L"Текстовые файлы (*.txt)\0*.txt\0Все файлы\0*.*\0";
    ofn.lpstrFile=file; ofn.nMaxFile=MAX_PATH; ofn.Flags=OFN_OVERWRITEPROMPT|OFN_PATHMUSTEXIST; ofn.lpstrDefExt=L"txt";
    if(GetSaveFileNameW(&ofn)) {
        int n=GetWindowTextLengthW(g_output); std::wstring s(n+1,L'\0'); GetWindowTextW(g_output,s.data(),n+1); s.resize(n);
        std::wofstream f(file); if(f) f<<s; SetStatus(L"Отчёт сохранён");
    }
}
static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch(msg) {
    case WM_CREATE: {
        g_window=hwnd;
        AddButton(hwnd,L"Оборудование",ID_HARDWARE,10,10);
        AddButton(hwnd,L"SMART / NVMe",ID_SMART,168,10);
        AddButton(hwnd,L"Диски",ID_DISKS,326,10);
        AddButton(hwnd,L"Self-test статус",ID_TEST_SHORT,484,10);
        AddButton(hwnd,L"Self-test SHORT",ID_TEST_LONG,642,10);
        AddButton(hwnd,L"Self-test LONG",ID_TEST_CANCEL,800,10);
        AddButton(hwnd,L"Отмена теста",ID_CANCEL_TEST,958,10);
        AddButton(hwnd,L"WHEA / RAM events",ID_DIAG,10,48);
        AddButton(hwnd,L"Процессы",ID_PROCESSES,168,48);
        AddButton(hwnd,L"Автозагрузка",ID_STARTUP,326,48);
        AddButton(hwnd,L"Индекс RAM",ID_RAM,484,48);
        AddButton(hwnd,L"TBW / история",ID_TBW,642,48);
        AddButton(hwnd,L"Временные файлы",ID_TEMP,800,48);
        AddButton(hwnd,L"Тест записи",ID_BENCH,958,48);
        AddButton(hwnd,L"Сохранить отчёт",ID_SAVE,10,86);
        g_output=CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",L"PC Performance Monitor C++ x64\r\nВыберите модуль сверху.",
            WS_CHILD|WS_VISIBLE|WS_VSCROLL|WS_HSCROLL|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY|ES_NOHIDESEL,
            10,126,1110,570,hwnd,(HMENU)200,g_instance,nullptr);
        g_status=CreateWindowW(L"STATIC",L"Готово",WS_CHILD|WS_VISIBLE,10,704,1100,24,hwnd,(HMENU)201,g_instance,nullptr);
        return 0;
    }
    case WM_SIZE: {
        if(g_output) MoveWindow(g_output,10,126,LOWORD(lp)-20,HIWORD(lp)-160,TRUE);
        if(g_status) MoveWindow(g_status,10,HIWORD(lp)-28,LOWORD(lp)-20,22,TRUE);
        return 0;
    }
    case WM_COMMAND:
        switch(LOWORD(wp)) {
        case ID_HARDWARE: StartTask(L"Оборудование",HardwareReport); break;
        case ID_SMART: StartTask(L"SMART и NVMe",SmartReport); break;
        case ID_DISKS: StartTask(L"Список накопителей",DiskList); break;
        case ID_TEST_SHORT: StartTask(L"Статус SMART self-test",SmartTests); break;
        case ID_TEST_LONG: {
            if(MessageBoxW(hwnd,L"Запустить короткий SMART-тест на всех обнаруженных smartctl дисках? Команда зависит от поддержки накопителя.",L"Подтверждение",MB_YESNO|MB_ICONQUESTION)==IDYES)
                StartTask(L"SMART SHORT",[] { return RunSmartTest(L"-t short"); });
            break;
        }
        case ID_TEST_CANCEL: {
            if(MessageBoxW(hwnd,L"Запустить длительный SMART-тест на всех обнаруженных smartctl дисках?",L"Подтверждение",MB_YESNO|MB_ICONWARNING)==IDYES)
                StartTask(L"SMART LONG",[] { return RunSmartTest(L"-t long"); });
            break;
        }
        case ID_CANCEL_TEST:
            if(MessageBoxW(hwnd,L"Отменить SMART self-test на всех обнаруженных smartctl устройствах?",L"Подтверждение",MB_YESNO|MB_ICONWARNING)==IDYES)
                StartTask(L"Отмена SMART self-test",[] { return RunSmartTest(L"-X"); });
            break;
        case ID_DIAG: StartTask(L"Системные события",DiagnosticsReport); break;
        case ID_PROCESSES: StartTask(L"Процессы",ProcessReport); break;
        case ID_STARTUP: StartTask(L"Автозагрузка",StartupReport); break;
        case ID_RAM: StartTask(L"Индекс RAM",RamIndex); break;
        case ID_TBW: StartTask(L"История TBW",TbwReport); break;
        case ID_TEMP: StartTask(L"Анализ временных файлов",TempScan); break;
        case ID_BENCH: if(MessageBoxW(hwnd,L"Выполнить запись тестового файла 128 MiB на системный временный каталог? Данные теста будут удалены.",L"Подтверждение",MB_YESNO|MB_ICONWARNING)==IDYES) StartTask(L"Тест записи",Benchmark); break;
        case ID_SAVE: SaveReport(); break;
        }
        return 0;
    case WM_APP_RESULT: {
        ShowResult((std::wstring*)lp);
        const unsigned remaining = --g_activeTasks;
        if (g_closing && remaining == 0) DestroyWindow(hwnd);
        else if (!g_closing) { EnableWindow(hwnd,TRUE); SetForegroundWindow(hwnd); }
        return 0;
    }
    case WM_CLOSE:
        g_closing = true;
        if (g_activeTasks.load() != 0) {
            SetStatus(L"Завершение фоновой операции перед закрытием...");
            EnableWindow(hwnd, FALSE);
            return 0;
        }
        DestroyWindow(hwnd);
        return 0;
    case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(hwnd,msg,wp,lp);
}

int WINAPI wWinMain(HINSTANCE hInst,HINSTANCE, PWSTR,int nCmdShow) {
    g_instance=hInst;
    INITCOMMONCONTROLSEX ic{sizeof(ic),ICC_STANDARD_CLASSES}; InitCommonControlsEx(&ic);
    WNDCLASSW wc{}; wc.lpfnWndProc=WndProc; wc.hInstance=hInst; wc.lpszClassName=L"PCPM_CPP_X64";
    wc.hCursor=LoadCursor(nullptr,IDC_ARROW); wc.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
    RegisterClassW(&wc);
    HWND hwnd=CreateWindowW(wc.lpszClassName,L"PC Performance Monitor — C++ x64 v1.3.6",
        WS_OVERLAPPEDWINDOW|WS_VISIBLE,CW_USEDEFAULT,CW_USEDEFAULT,1160,790,nullptr,nullptr,hInst,nullptr);
    if(!hwnd) return 1;
    ShowWindow(hwnd,nCmdShow); UpdateWindow(hwnd);
    MSG msg{}; while(GetMessageW(&msg,nullptr,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}
    return (int)msg.wParam;
}
